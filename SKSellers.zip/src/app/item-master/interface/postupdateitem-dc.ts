export interface postupdateitemDC {
    ItemId : number;
    ItemMultiMRPId : number;
    POPurchasePrice : number;
    Discount : number;
    Margin : number;
    UnitPrice : number;
    ItemlimitQty : number;
    IsItemLimit : boolean;
    active : boolean;
    PurchasePrice : number;
    PrimePrice : number;
    IsPrimeActive : boolean;
}