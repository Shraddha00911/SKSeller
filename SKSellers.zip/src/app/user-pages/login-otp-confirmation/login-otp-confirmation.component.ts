import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-otp-confirmation',
  templateUrl: './login-otp-confirmation.component.html',
  styleUrls: ['./login-otp-confirmation.component.scss']
})
export class LoginOtpConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
