
    export interface ItemSchemeMasterdetailsDc {
        ItemSchemeDetailId: number;
        ItemSchemeMasterId: number;
        IsActive: boolean;
    }
    export interface ItemSchemeMasterDc {
        Id: number;
        StartDate: any;
        EndDate: any;
        UploadedSheetUrl:string;
    }
    
    
    

