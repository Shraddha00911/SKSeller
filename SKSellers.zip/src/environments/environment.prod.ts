export const environment = {
  //apiBaseUrl: 'https://localhost:26265',
 apiBaseUrl: 'https://uat.shopkirana.in',
  production: true,
  apiKeyGoogle : 'WsdfSyD5fRk6-UwGVAWWKEEd5IWtm4yxppzP6_xs'
};
